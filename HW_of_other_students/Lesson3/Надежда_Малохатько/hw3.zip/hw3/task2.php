<?php
$arr = [];
for ($i = 0; $i < 10; $i++) {
    $arr[$i] = $i + 1;
    echo $arr[$i] . '<br />';
}
print_r($arr);