<?php
define('IS_INCLUDE',1);
echo 'Оределили константу "IS_INCLUDE" и включили ее в основной файл';
echo '<br />';