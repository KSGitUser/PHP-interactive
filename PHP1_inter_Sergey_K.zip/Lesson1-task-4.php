<?php
  echo "Текущие дата и время: ";
  echo date('d.m.Y G:i');